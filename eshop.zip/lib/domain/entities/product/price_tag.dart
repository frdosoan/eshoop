class PriceTag {
  final String id;
  final String name;
  final num price;
  final num special;

  PriceTag({
    required this.id,
    required this.name,
    required this.price,
    required this.special,
  });
}
