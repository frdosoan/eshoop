import 'dart:convert';

import 'package:eshop/core/services/app_manager.dart';
import 'package:http/http.dart' as http;

import '../../../../core/error/exceptions.dart';
import '../../../core/constant/strings.dart';
import '../../../domain/usecases/product/get_product_usecase.dart';
import '../../models/product/product_response_model.dart';

abstract class ProductRemoteDataSource {
  Future<ProductResponseModel> getProducts(FilterProductParams params);
}

class ProductRemoteDataSourceImpl implements ProductRemoteDataSource {
  final http.Client client;
  ProductRemoteDataSourceImpl({required this.client});

  @override
  Future<ProductResponseModel> getProducts(params) =>
      _getProductFromUrl('$baseUrl/product', {
        "keyword": params.keyword.toString(),
        "pageSize": params.pageSize.toString(),
        "page": params.limit.toString(),
        "categories": jsonEncode(params.categories.map((e) => e.id).toList()),
      });

  Future<ProductResponseModel> _getProductFromUrl(String url, Map body) async {
    print(AppManager.instance.appToken);
    final response = await client.post(
      Uri.parse(url),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        if (AppManager.instance.appToken != null)
          "api_token": AppManager.instance.appToken ?? "",
      },
      body: body,
    );
    if (response.statusCode == 200) {
      print(response.body);
      return productResponseModelFromJson(response.body);
    } else {
      print(url);

      throw ServerException();
    }
  }
}
