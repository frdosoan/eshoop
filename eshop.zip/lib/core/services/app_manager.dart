import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constant/strings.dart';

class AppManager {
  AppManager._internal();
  factory AppManager() => instance;
  static final instance = AppManager._internal();

  String? appToken;
  bool isInitialized = false;

  Future<void> init() async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "username": "frdosoan",
          "key": "dTtbELhV5Ackwe0wHOqkVuBxojPm1XdlnKCb2TWKsnhYxs8WaHOgaxl4nWHO0ebKZX4UiQ4cwgYN5QsR2DmHGhDulvNXHt3Vy0vTv4tQV6oeEs0leIxUV7EACqywEeMUww6yMwjvOeLTsTJnVJMNvoMRj2lj4QCGeFm1m0FjfMcIFM6SnKb1Ed22qFC2LspIr6aJ8O6Dy3PfnYRyBH61lv5dsz4mZjbGB7mQjdH0nlXKZqfh6BrLudePS7fhRzm2"
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        appToken = data["api_token"];
        isInitialized = true;
      } else {
        throw Exception('Failed to initialize AppManager: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('AppManager initialization error: $e');
    }
  }
}