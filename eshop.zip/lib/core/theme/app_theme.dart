import 'package:flutter/material.dart';
import 'package:eshop/core/constant/colors.dart'; // تأكد من أن المسار صحيح

class AppTheme {
  const AppTheme._();

  static final lightTheme = ThemeData(
    brightness: Brightness.light,
    primaryColor: kLightPrimaryColor,
    visualDensity: VisualDensity.adaptivePlatformDensity,
    scaffoldBackgroundColor: kLightBackgroundColor,
    appBarTheme: AppBarTheme(
      backgroundColor: kLightBackgroundColor, // استخدام لون الخلفية الفاتح
      foregroundColor: kLightTextColor, // لون النص في الوضع الفاتح
      elevation: 0,
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: kLightPrimaryColor),
    ),
    colorScheme: ColorScheme.light(
      primary: kLightPrimaryColor,
      secondary: kLightSecondaryColor,
      background: kLightBackgroundColor,
    ),
  );

  static final darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: kDarkPrimaryColor,
    visualDensity: VisualDensity.adaptivePlatformDensity,
    scaffoldBackgroundColor: kDarkBackgroundColor,
    appBarTheme: AppBarTheme(
      backgroundColor: kDarkPrimaryColor, // استخدام لون الخلفية الداكن
      foregroundColor: kDarkTextColor, // لون النص في الوضع الداكن
      elevation: 0,
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: kDarkAccentColor),
    ),
    colorScheme: ColorScheme.dark(
      primary: kDarkPrimaryColor,
      secondary: kDarkAccentColor,
      background: kDarkBackgroundColor,
    ),
  );
}