// App
const String appTitle = 'EShop';
const String domainUri = 'https://app.frdossmart.com/';

// Networking and APIs
const String baseUrl =
    '${domainUri}index.php?route=api';


const String imageCashUri = "${domainUri}image";
const String defaultApiKey = '';
const String defaultSources = '';

// Storage and Databases
const String articlesTableName = '';
const String databaseName = '';
