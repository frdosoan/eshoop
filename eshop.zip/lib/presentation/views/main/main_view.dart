import 'package:flutter/material.dart'; // استيراد مكتبة Flutter الأساسية لواجهة المستخدم
import 'package:flutter_bloc/flutter_bloc.dart'; // استيراد مكتبة Bloc لإدارة الحالة

//import '../../blocs/filter/filter_cubit.dart';
import '../../blocs/home/navbar_cubit.dart'; // استيراد NavbarCubit لإدارة حالة الشريط السفلي
import 'cart/cart_view.dart'; // استيراد صفحة العربة
import 'category/category_view.dart'; // استيراد صفحة الفئات
import 'home/home_view.dart'; // استيراد صفحة الرئيسية
import 'other/other_view.dart'; // استيراد صفحة أخرى

// تعريف شاشة MainView كعنصر قابل للتغيير (StatefulWidget)
class MainView extends StatefulWidget {
  const MainView({Key? key}) : super(key: key); // المُنشئ

  @override
  State<MainView> createState() => _MainViewState(); // إنشاء حالة الشاشة
}

// تعريف حالة شاشة MainView
class _MainViewState extends State<MainView> {
  int _selectedIndex = 0; // متغير لتتبع الأيقونة المحددة
  Map<int, bool> _isTextVisible = {}; // متغير لتتبع ظهور النص لكل أيقونة

  @override
  Widget build(BuildContext context) {
    // بناء واجهة المستخدم باستخدام Scaffold (هيكل أساسي للشاشة)
    return Scaffold(
      body: Stack( // استخدام Stack لوضع العناصر فوق بعضها البعض
        children: [
          // عرض المحتوى بناءً على حالة NavbarCubit
          BlocBuilder<NavbarCubit, int>(
            builder: (context, state) {
              return AnimatedContainer( // حاوية متحركة للانتقال بين الصفحات
                duration: const Duration(seconds: 0), // مدة الانتقال (0 يعني انتقال فوري)
                child: PageView( // عرض الصفحات المختلفة
                  physics: const NeverScrollableScrollPhysics(), // منع التمرير بين الصفحات
                  controller: context.read<NavbarCubit>().controller, // التحكم في PageView
                  children: const <Widget>[
                    HomeView(), // صفحة الرئيسية
                    CategoryView(), // صفحة الفئات
                    CartView(), // صفحة العربة
                    OtherView(), // صفحة أخرى
                    // يمكنك إضافة صفحة البحث هنا إذا لزم الأمر (مثل SearchView())
                   // FilterCubit(),
                  //  FilterCubit(),
                  ],
                ),
              );
            },
          ),
          // محاذاة الشريط السفلي إلى الأسفل والوسط
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 0), // مسافة من الأسفل
              child: BlocBuilder<NavbarCubit, int>(
                builder: (context, state) {
                  return Container( // حاوية لخلفية الشريط السفلي
                    decoration: BoxDecoration(
                      color: Colors.grey[800], // لون الخلفية (رمادي داكن)
                      borderRadius: BorderRadius.circular(12), // تدوير زوايا الشريط السفلي
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 0), // مسافة داخلية للشريط السفلي
                    child: Row( // ترتيب الأيقونات بجانب بعضها البعض
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly, // توزيع الأيقونات بالتساوي
                      children: [
                        // أيقونة الصفحة الرئيسية
                        _buildNavItem(0, Icons.home, 'الرئيسية'),
                        // أيقونة صفحة الفئات
                        _buildNavItem(1, Icons.category, 'الفئات'),
                        // أيقونة العربة (بارزة ومرتفعة)
                        _buildCartItem(),
                        // أيقونة البحث
                        _buildNavItem(4, Icons.search, 'بحث'),
                        // أيقونة صفحة أخرى
                        _buildNavItem(3, Icons.person, 'الحساب'),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  // دالة لبناء أيقونة وعرض اسمها عند الضغط
  Widget _buildNavItem(int index, IconData icon, String label) {
    bool isSelected = _selectedIndex == index; // تحديد ما إذا كانت الأيقونة محددة
    bool isTextVisible = _isTextVisible[index] ?? false; // تحديد ما إذا كان النص ظاهرًا

    return GestureDetector( // كشف النقرات على الأيقونة
      onTap: () {
        setState(() {
          _selectedIndex = index; // تحديد الأيقونة المحددة
          _isTextVisible.updateAll((key, value) => false); // إخفاء جميع النصوص الأخرى
          _isTextVisible[index] = !isTextVisible; // تبديل حالة ظهور النص
        });
        context.read<NavbarCubit>().controller.animateToPage(
            index, duration: const Duration(milliseconds: 300), curve: Curves.easeOut); // الانتقال إلى الصفحة
        context.read<NavbarCubit>().update(index); // تحديث حالة الشريط السفلي
      },
      child: Column( // ترتيب الأيقونة والنص عموديًا
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 30, color: isSelected ? Colors.white : Colors.grey), // عرض الأيقونة
          Visibility( // عرض النص فقط عند الضغط
            visible: isTextVisible,
            child: Text(label, style: TextStyle(color: isSelected ? Colors.white : Colors.grey)),
          ),
        ],
      ),
    );
  }

  // دالة لبناء أيقونة العربة (بارزة ومرتفعة)
  Widget _buildCartItem() {
    bool isSelected = _selectedIndex == 2; // تحديد ما إذا كانت الأيقونة محددة
    bool isTextVisible = _isTextVisible[2] ?? false; // تحديد ما إذا كان النص ظاهرًا

    return GestureDetector( // كشف النقرات على الأيقونة
      onTap: () {
        setState(() {
          _selectedIndex = 2; // تحديد الأيقونة المحددة
          _isTextVisible.updateAll((key, value) => false); // إخفاء جميع النصوص الأخرى
          _isTextVisible[2] = !isTextVisible; // تبديل حالة ظهور النص
        });
        context.read<NavbarCubit>().controller.animateToPage(
            2, duration: const Duration(milliseconds: 300), curve: Curves.easeOut); // الانتقال إلى صفحة العربة
        context.read<NavbarCubit>().update(2); // تحديث حالة الشريط السفلي
      },
      child: Transform.translate( // رفع الأيقونة إلى الأعلى
        offset: const Offset(0, -20),
        child: Column( // ترتيب الأيقونة والنص عموديًا
          mainAxisSize: MainAxisSize.min,
          children: [
            Container( // حاوية لخلفية الأيقونة
              decoration: BoxDecoration(
                shape: BoxShape.circle, // جعل الخلفية دائرية
                color: Colors.deepOrange, // لون الخلفية (برتقالي داكن)
              ),
              padding: const EdgeInsets.all(12),
              child: const Icon(Icons.shopping_cart, size: 36, color: Colors.white), // عرض الأيقونة
            ),
            Visibility( // عرض النص فقط عند الضغط
              visible: isTextVisible,
              child: Text('العربة', style: TextStyle(color: isSelected ? Colors.white : Colors.grey)),
            ),
          ],
        ),
      ),
    );
  }
}