import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

import '../../../core/constant/images.dart';
import '../../../core/error/failures.dart';
import '../../../core/router/app_router.dart';
import '../../../domain/usecases/user/sign_in_usecase.dart';
import '../../blocs/user/user_bloc.dart';
import '../../widgets/input_form_button.dart';
import '../../widgets/input_text_form_field.dart';

class SignInView extends StatefulWidget {
  const SignInView({Key? key}) : super(key: key);

  @override
  State<SignInView> createState() => _SignInViewState();
}

class _SignInViewState extends State<SignInView> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return BlocListener<UserBloc, UserState>(
      listener: (context, state) {
        if (state is UserLoading) {
          EasyLoading.show(status: 'جاري التحميل...');
        } else if (state is UserLogged) {
          EasyLoading.dismiss();
          Navigator.of(context).pushNamedAndRemoveUntil(
            AppRouter.home,
                (route) => false,
          );
        } else if (state is UserLoggedFail) {
          EasyLoading.dismiss();
          if (state.failure is CredentialFailure) {
            EasyLoading.showError("اسم المستخدم أو كلمة المرور غير صحيحة!");
          } else {
            EasyLoading.showError("حدث خطأ. يرجى المحاولة مرة أخرى.");
          }
        }
      },
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 50),
                  SizedBox(
                    height: 80,
                    child: Image.asset(kAppLogo, color: Colors.black),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "الرجاء إدخال عنوان البريد الإلكتروني وكلمة المرور لتسجيل الدخول",
                    style: TextStyle(fontSize: 16, color: Colors.black54),
                    textAlign: TextAlign.center,
                  ),
                  const Spacer(flex: 2),
                  const SizedBox(height: 24),
                  InputTextFormField(
                    controller: emailController,
                    textInputAction: TextInputAction.next,
                    hint: 'البريد الإلكتروني',
                    validation: (String? val) {
                      if (val == null || val.isEmpty) {
                        return 'هذا الحقل لا يمكن أن يكون فارغًا';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),
                  InputTextFormField(
                    controller: passwordController,
                    textInputAction: TextInputAction.go,
                    hint: 'كلمة المرور',
                    isSecureField: true,
                    validation: (String? val) {
                      if (val == null || val.isEmpty) {
                        return 'هذا الحقل لا يمكن أن يكون فارغًا';
                      }
                      return null;
                    },
                    onFieldSubmitted: (_) {
                      if (_formKey.currentState!.validate()) {
                        _signIn();
                      }
                    },
                  ),
                  const SizedBox(height: 10),
                  Align(
                    alignment: Alignment.centerRight,
                    child: InkWell(
                      onTap: () {
                        // Navigator.pushNamed(context, AppRouter.forgotPassword);
                      },
                      child: const Text(
                        'نسيت كلمة المرور؟',
                        style: TextStyle(fontSize: 14),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  InputFormButton(
                    color: Colors.black87,
                    onClick: _signIn,
                    titleText: 'تسجيل الدخول',
                  ),
                  const SizedBox(height: 10),
                  InputFormButton(
                    color: Colors.black87,
                    onClick: () {
                      Navigator.of(context).pop();
                    },
                    titleText: 'رجوع',
                  ),
                  // نقل الجزء الخاص بـ "ليس لديك حساب؟ تسجيل" إلى هنا
                  Padding(
                    padding: const EdgeInsets.only(top: 16, bottom: 16), // إضافة مساحة أعلى
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          'ليس لديك حساب؟ ',
                          style: TextStyle(fontSize: 14),
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.pushNamed(context, AppRouter.signUp);
                          },
                          child: const Text(
                            'تسجيل',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(), // إبقاء الـ Spacer في الأسفل
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _signIn() {
    if (_formKey.currentState!.validate()) {
      context.read<UserBloc>().add(SignInUser(SignInParams(
        username: emailController.text,
        password: passwordController.text,
      )));
    }
  }
}