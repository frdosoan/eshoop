package com.frdos.eshop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
